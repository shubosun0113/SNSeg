#' @useDynLib SNSeg, .registration=TRUE
#' @importFrom Rcpp evalCpp
NULL

#' @importFrom utils data
#' @importFrom stats approx
#' @importFrom graphics par
#' @importFrom graphics plot
#' @importFrom graphics abline
#' @importFrom stats pnorm
NULL

#' Self-normalization change point estimates for univariate time series based on
#' multi-parameters' changes
#'
#' The function \code{SNSeg_Uni_multi_para} is a multi-parameter change point
#' estimation framework for a univariate time series using the self-normalized
#' approach.
#'
#' @param ts numeric data of a univariate time series
#' @param paras_to_test the multi-parameters of ts to be measured and tested.
#' The type(s) of input for paras_to_test includes "mean", "variance", "acf",
#' and all numeric value of quantile(s) between 0 and 1.
#' @param d the dimension of paras_to_test
#' @param confidence the confidence level that can be expected to produce a
#' significant Self-normalization test statistic
#' @param grid_size_scale the window size parameter to determine the mimimum
#' range where an estimated change point for a time series can occur
#' @param grid_size the window size to cover an estimated change point, which is
#' calculated from grid_size_scale. The function depends on the value of
#' grid_size instead of grid_size_scale within input, and only when grid_size is
#' NULL will the function use the grid_size_scale in the input.
#' @param plot_SN Only if argument plot_SN is TRUE will return a SN segmentation
#' plot
#' @return \code{SNSeg_Uni_multi_para} returns the type of the multivariate time
#' series, the minimum window size to cover a change point, and the lags where
#' all estimated change points take place.
#' \describe{
#'   \item{\code{parameter}}{the type of parameter being used for
#'   self-normalization}
#'   \item{\code{grid_size}}{the minimal window size to detect a potential
#'   change point}
#'   \item{\code{SN_sweep_result}}{a list of matrices to record the test
#'   statistics, the location of the estimated change points, and the range of
#'   the window set to contain each change point}
#'   \item{\code{est_cp}}{the estimated change points for the given time series}
#'   \item{\code{confidence}}{the confidence level for SN tests}
#'   \item{\code{critical_value}}{the critical value for SN change points
#'   estimation}
#' }
#' @examples
#' set.seed(7)
#' n <- 1000
#' cp_sets <- c(0,333,667,1000)
#' no_seg <- length(cp_sets)-1
#' rho <- 0
#' # AR time series with no change-point (mean, var)=(0,1)
#' ts <- MAR(n, 2, rho)*sqrt(1-rho^2)
#' no_seg <- length(cp_sets)-1
#' sd_shift <- c(1,1.6,1)
#' for(index in 1:no_seg){ # Mean shift
#'   tau1 <- cp_sets[index]+1
#'   tau2 <- cp_sets[index+1]
#'   ts[tau1:tau2,] <- ts[tau1:tau2,]*sd_shift[index]
#' }
#' d <- 2
#' ts <- ts[,2]
#'
#' # 90th and 95th quantile with grid_size undefined
#' SNSeg_Uni_multi_para(ts, paras_to_test = c(0.9,0.95),
#'                      confidence = 0.9, grid_size_scale = 0.05, grid_size = NULL,
#'                      d = 2, plot_SN = FALSE)
#'
#' # 90th quantile and the variance with grid_size undefined
#' SNSeg_Uni_multi_para(ts, paras_to_test = c(0.9,'variance'),
#'                      confidence = 0.95, grid_size_scale = 0.078, grid_size = NULL,
#'                      d = 2, plot_SN = FALSE)
#'
#' # 90th quantile, variance and acf with grid_size undefined
#' SNSeg_Uni_multi_para(ts, paras_to_test = c(0.9,'variance',"acf"),
#'                      confidence = 0.9, grid_size_scale = 0.064, grid_size = NULL,
#'                      d = 3, plot_SN = TRUE)
#'
#' # 60th quantile, mean, variance and acf with grid_size defined
#' SNSeg_Uni_multi_para(ts, paras_to_test = c(0.6,'mean',"variance","acf"),
#'                      confidence = 0.9, grid_size_scale = 0.05, grid_size = 83,
#'                      d = 4, plot_SN = TRUE)
#'
#' @export SNSeg_Uni_multi_para
SNSeg_Uni_multi_para <- function(ts, paras_to_test = c(0.9,0.95),
                                confidence = 0.9, grid_size_scale = 0.05,
                                grid_size = NULL, d = 2, plot_SN = FALSE){
  if(is.null(ts))
  {stop("Input of ts is missing!")}
  if(class(ts)[1] != "numeric"){
    stop("ts must be numeric!")
  }
  if(!(confidence %in% c(0.9,0.95,0.99,0.995,0.999))){
    stop("Confidence must be one of 0.9, 0.95, 0.99, 0.995 and 0.999!")
  }

  if(length(paras_to_test)!=d){
    stop("The length of paras_to_test must be equal to d!")
  }

  paras_to_test_list <- lapply(paras_to_test, function(col) {
    if (suppressWarnings(all(!is.na(as.numeric(as.character(col)))))) {
      as.numeric(as.character(col))
    } else {
      col
    }
  })
  for(para in paras_to_test_list){
    if(!is.numeric(para)){
      if(!(para %in% c("mean","variance","acf")))
        stop("Categorical inputs of paras_to_test
             must be within mean, variance or acf!")
    }
    if(is.numeric(para)){
      if((para<=0)|(para>=1))
        stop("Numeric inputs of paras_to_test must be between 0 and 1!")
    }
  }
  n <- length(ts)
  critical_values_multi <- SNSeg::critical_values_multi
  # interpolation for grid_size_scale
  if((is.null(grid_size))&(is.null(grid_size_scale))){
    grid_size_scale <- 0.05
    SN_critical <- critical_values_multi[critical_values_multi[,2]==d & critical_values_multi[,1]==grid_size_scale,]
    posi_confidence <- match(as.character(confidence),colnames(critical_values_multi))
    critical_value <- SN_critical[1,posi_confidence]
    grid_size <- round(grid_size_scale*n)
    warning("Undefined value detected for both grid_size and grid_size_scale! The system would use 0.05 as the default for grid_size_scale.")
  } else if((is.null(grid_size))&(!is.null(grid_size_scale))){
    if(grid_size_scale<0.05){
      grid_size_scale <- 0.05
      SN_critical <- critical_values_multi[critical_values_multi[,2]==d & critical_values_multi[,1]==grid_size_scale,]
      posi_confidence <- match(as.character(confidence),colnames(critical_values_multi))
      critical_value <- SN_critical[1,posi_confidence]
      grid_size <- round(grid_size_scale*n)
      warning("Detected the grid_size_scale is less than 0.05. The system would use 0.05 for grid_size_scale.")
    } else if(grid_size_scale>0.5){
      grid_size_scale <- 0.5
      SN_critical <- critical_values_multi[critical_values_multi[,2]==d & critical_values_multi[,1]==grid_size_scale,]
      posi_confidence <- match(as.character(confidence),colnames(critical_values_multi))
      critical_value <- SN_critical[1,posi_confidence]
      grid_size <- round(grid_size_scale*n)
      warning("Detected the grid_size_scale is greater than 0.5. The system would use 0.5 for grid_size_scale.")
    } else if(grid_size_scale>=0.05 & grid_size_scale<=0.5){
      if((grid_size_scale %in% critical_values_multi[,1])){
        SN_critical <- critical_values_multi[critical_values_multi[,2]==d & critical_values_multi[,1]==grid_size_scale,]
        posi_confidence <- match(as.character(confidence),colnames(critical_values_multi))
        critical_value <- SN_critical[1,posi_confidence]
        grid_size <- round(grid_size_scale*n)
      } else if(!(grid_size_scale %in% critical_values_multi[,1])){
        grid_size <- round(grid_size_scale*n)
        SN_critical <- critical_values_multi[critical_values_multi[,2]==d,]
        posi_epsilon <- match(grid_size_scale,sort(c(SN_critical[,1],grid_size_scale)))
        posi_confidence <- match(as.character(confidence),colnames(critical_values_multi))
        critical_vector <- c(SN_critical[(posi_epsilon-1):posi_epsilon,posi_confidence])
        epsilon_vector <- c(SN_critical[(posi_epsilon-1):posi_epsilon,1])
        critical_value <- approx(epsilon_vector,critical_vector,xout = grid_size_scale)$y
      }
    }
  } else if(!is.null(grid_size)){
    grid_size_scale <- grid_size/n
    if(grid_size_scale<0.05){
      grid_size_scale <- 0.05
      grid_size <- round(grid_size_scale*n)
      SN_critical <- critical_values_multi[critical_values_multi[,2]==d & critical_values_multi[,1]==grid_size_scale,]
      posi_confidence <- match(as.character(confidence),colnames(critical_values_multi))
      critical_value <- SN_critical[1,posi_confidence]
      warning("Detected the grid_size_scale is less than 0.05 from the current grid_size. The system would use 0.05 for grid_size_scale.")
    }
    if(grid_size_scale>0.5){
      grid_size_scale <- 0.5
      grid_size <- round(grid_size_scale*n)
      SN_critical <- critical_values_multi[critical_values_multi[,2]==d & critical_values_multi[,1]==grid_size_scale,]
      posi_confidence <- match(as.character(confidence),colnames(critical_values_multi))
      critical_value <- SN_critical[1,posi_confidence]
      warning("Detected the grid_size_scale is greater than 0.5 from the current grid_size. The system would use 0.5 for grid_size_scale.")
    }
    if(grid_size_scale>=0.05 & grid_size_scale<=0.5){
      if((grid_size_scale %in% critical_values_multi[,1])){
        SN_critical <- critical_values_multi[critical_values_multi[,2]==d & critical_values_multi[,1]==grid_size_scale,]
        posi_confidence <- match(as.character(confidence),colnames(critical_values_multi))
        critical_value <- SN_critical[1,posi_confidence]
      } else if(!(grid_size_scale %in% critical_values_multi[,1])){
        SN_critical <- critical_values_multi[critical_values_multi[,2]==d,]
        posi_epsilon <- match(grid_size_scale,sort(c(SN_critical[,1],grid_size_scale)))
        posi_confidence <- match(as.character(confidence),colnames(critical_values_multi))
        critical_vector <- c(SN_critical[(posi_epsilon-1):posi_epsilon,posi_confidence])
        epsilon_vector <- c(SN_critical[(posi_epsilon-1):posi_epsilon,1])
        critical_value <- approx(epsilon_vector,critical_vector,xout = grid_size_scale)$y
      }
    }
  }

  SN_sweep_result <- suppressWarnings(SN_sweep_multiparameter(ts, grid_size, paras_to_test))
  SN_result <- SN_divisive_path(start=1, end=n, grid_size, SN_sweep_result, critical_value=critical_value)

  if(plot_SN){
    plot(ts, xlab = "Time", ylab = "Value",
         main="SN Segmentation plot")
    abline(v=SN_result)
  }
  return(list("parameter" = paras_to_test, "grid_size" = grid_size,
              "confidence" = confidence,"est_cp" = SN_result, "SN_sweep_result" = SN_sweep_result,
              "critical_value" = critical_value))
}
