#' Critical Values of Self-normalization for single-parameter
#'
#' A dataset containing the critical value of each window size at each
#' confidence level for Self-normalization change points estimate based on
#' one single parameter.
#'
#' @name critical_values_single
#' @docType data
#' @format A data frame with 6 variables:
#' \describe{
#' \item{\code{epsilon}}{window size to estimate change points}
#' \item{\code{0.9}}{critical value at confidence level \code{0.9}}
#' \item{\code{0.95}}{critical value at confidence level \code{0.95}}
#' \item{\code{0.99}}{critical value at confidence level \code{0.99}}
#' \item{\code{0.995}}{critical value at confidence level \code{0.995}}
#' \item{\code{0.999}}{critical value at confidence level \code{0.999}}
#' }
#'
"critical_values_single"

#' Critical Values of Self-normalization for multi-parameters
#'
#' A dataset containing the critical value of each window size at each
#' confidence level for Self-normalization change points estimate based on
#' multi-parameters.
#'
#' @name critical_values_multi
#' @docType data
#' @format A data frame with 7 variables:
#' \describe{
#' \item{\code{epsilon}}{window size to estimate change points}
#' \item{\code{p}}{dimension of the multi-parameters}
#' \item{\code{0.9}}{critical value at confidence level \code{0.9}}
#' \item{\code{0.95}}{critical value at confidence level \code{0.95}}
#' \item{\code{0.99}}{critical value at confidence level \code{0.99}}
#' \item{\code{0.995}}{critical value at confidence level \code{0.995}}
#' \item{\code{0.999}}{critical value at confidence level \code{0.999}}
#' }
#'
"critical_values_multi"

#' Critical Values of Self-normalization for high-dimensional time
#' series (SNHD)
#'
#' A dataset containing the critical value of each window size at each
#' confidence level for SNHD.
#' @name critical_values_HD
#' @docType data
#' @format A data frame with 6 variables:
#' \describe{
#' \item{\code{epsilon}}{window size to estimate change points}
#' \item{\code{0.9}}{critical value at confidence level \code{0.9}}
#' \item{\code{0.95}}{critical value at confidence level \code{0.95}}
#' \item{\code{0.99}}{critical value at confidence level \code{0.99}}
#' \item{\code{0.995}}{critical value at confidence level \code{0.995}}
#' \item{\code{0.999}}{critical value at confidence level \code{0.999}}
#' }
#'
"critical_values_HD"
