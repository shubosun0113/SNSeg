#' @useDynLib SNSeg, .registration=TRUE
#' @importFrom stats rnorm
NULL

#' A Funtion to generate a multivariate autoregressive process (MAR) model in
#' time series
#'
#' The function \code{MAR} is used for generating MAR model(s) for examples
#' under \code{SNSeg_Uni_single_para}, \code{SNSeg_Uni_multi_para}, and
#' \code{SNSeg_Multi}.
#'
#' @param n the size of time series to be generated
#' @param reptime the number of time series to be generated
#' @param rho a correlation factor
#'
#' @export MAR
MAR <- function(n, reptime, rho){
  inter <- matrix(0, n+30, reptime)
  epsilon <- matrix(rnorm((n+30)*reptime,0,1),(n+30),reptime)
  for (j in 1:(n+29)){
    inter[j+1,1:reptime] <- epsilon[j+1,1:reptime]+rho*inter[j,1:reptime]
  }
  return(inter[31:(n+30),1:reptime])
}

#' @useDynLib SNSeg, .registration=TRUE
#' @importFrom stats rnorm
NULL

#' A Funtion to generate a multivariate autoregressive process (MAR) model in
#' time series (used for testing change points based on variance and ACF)
#'
#' The function \code{MAR_Variance} is used for generating MAR model(s) for
#' examples under \code{SNSeg_Uni_single_para}, \code{SNSeg_Uni_multi_para}, and
#' \code{SNSeg_Multi}.
#'
#' @param reptime the number of time series to be generated
#' @param type the type of time series for simulation, which includes V1, V2, V3
#' , A1, A2 and A3. The V-beginnings are for testing variance, and the
#' A-beginnings are for testing ACF.
#'
#' @export MAR_Variance
MAR_Variance <- function(reptime, type='V3'){
  burnin <- 50
  if(type=='V1'){
    n <- 1024
    inter <- matrix(0, n+burnin, reptime)
    epsilon <- matrix(rnorm((n+burnin)*reptime,0,1),(n+burnin),reptime)
    cp_sets <- c(0,400,750,1024)
    no_seg <- length(cp_sets)-1
    rho_sets <- list(c(0.5),c(0.5),c(0.5))
    sd_sets <- list(c(1),c(2),c(1))
    for(j in 1:(burnin-1)){
      inter[j+1,1:reptime] <- sd_sets[[1]]*epsilon[j+1,1:reptime]+rho_sets[[1]]*inter[j,1:reptime]
    }
    for(index in 1:no_seg){ # Mean shift
      tau1 <- cp_sets[index]+burnin
      tau2 <- cp_sets[index+1]+burnin-1
      for(j in tau1:tau2){
        inter[j+1,1:reptime] <- sd_sets[[index]]*epsilon[j+1,1:reptime]+rho_sets[[index]]%*%inter[j:(j-length(rho_sets[[index]])+1),1:reptime]
      }
    }
  }
  if(type=='V2'){
    n <- 1024
    inter <- matrix(0, n+burnin, reptime)
    epsilon <- matrix(rnorm((n+burnin)*reptime,0,1),(n+burnin),reptime)
    cp_sets <- c(0,125,532,704,1024)
    no_seg <- length(cp_sets)-1
    rho_sets <- list(c(0.7),c(0.3),c(0.9),c(0.1))
    sd_sets <- list(c(1,0.6),c(1,0.3),c(1),c(1,-0.5))
    for(j in 2:(burnin-1)){
      inter[j+1,1:reptime] <- sd_sets[[1]]%*%epsilon[(j+1):(j-length(sd_sets[[1]])+2),1:reptime]+rho_sets[[1]]*inter[j,1:reptime]
    }
    for(index in 1:no_seg){ # Mean shift
      tau1 <- cp_sets[index]+burnin
      tau2 <- cp_sets[index+1]+burnin-1
      for(j in tau1:tau2){
        inter[j+1,1:reptime] <- sd_sets[[index]]%*%epsilon[(j+1):(j-length(sd_sets[[index]])+2),1:reptime]+rho_sets[[index]]*inter[j,1:reptime]
      }
    }
  }
  if(type=='V3'){
    n <- 1024
    inter <- matrix(0, n+burnin, reptime)
    epsilon <- matrix(rnorm((n+burnin)*reptime,0,1),(n+burnin),reptime)
    cp_sets <- c(0,512,768,1024)
    no_seg <- length(cp_sets)-1
    rho_sets <- list(c(0.9), c(1.69,-0.81), c(1.32,-0.81))
    for(j in 1:(burnin-1)){
      inter[j+1,1:reptime] <- epsilon[j+1,1:reptime]+rho_sets[[1]]*inter[j,1:reptime]
    }
    for(index in 1:no_seg){ # Mean shift
      tau1 <- cp_sets[index]+burnin
      tau2 <- cp_sets[index+1]+burnin-1
      for(j in tau1:tau2){
        inter[j+1,1:reptime] <- epsilon[j+1,1:reptime]+rho_sets[[index]]%*%inter[j:(j-length(rho_sets[[index]])+1),1:reptime]
      }
    }
  }
  if(type=='A1'){
    n <- 1024
    inter <- matrix(0, n+burnin, reptime)
    epsilon <- matrix(rnorm((n+burnin)*reptime,0,1),(n+burnin),reptime)
    cp_sets <- c(0,400,750,1024)
    no_seg <- length(cp_sets)-1
    rho_sets <- list(c(0.5),c(0.9),c(0.3))
    for(j in 1:(burnin-1)){
      inter[j+1,1:reptime] <- epsilon[j+1,1:reptime]+rho_sets[[1]]*inter[j,1:reptime]
    }
    for(index in 1:no_seg){ # Mean shift
      tau1 <- cp_sets[index]+burnin
      tau2 <- cp_sets[index+1]+burnin-1
      for(j in tau1:tau2){
        inter[j+1,1:reptime] <- epsilon[j+1,1:reptime]+rho_sets[[index]]%*%inter[j:(j-length(rho_sets[[index]])+1),1:reptime]
      }
    }
  }
  if(type=='A2'){
    n <- 1024
    inter <- matrix(0, n+burnin, reptime)
    epsilon <- matrix(rnorm((n+burnin)*reptime,0,1),(n+burnin),reptime)
    cp_sets <- c(0,50,1024)
    no_seg <- length(cp_sets)-1
    rho_sets <- list(c(0.75),c(-0.5))
    for(j in 1:(burnin-1)){
      inter[j+1,1:reptime] <- epsilon[j+1,1:reptime]+rho_sets[[1]]*inter[j,1:reptime]
    }
    for(index in 1:no_seg){ # Mean shift
      tau1 <- cp_sets[index]+burnin
      tau2 <- cp_sets[index+1]+burnin-1
      for(j in tau1:tau2){
        inter[j+1,1:reptime] <- epsilon[j+1,1:reptime]+rho_sets[[index]]%*%inter[j:(j-length(rho_sets[[index]])+1),1:reptime]
      }
    }
  }
  if(type=='A3'){
    n <- 1024
    inter <- matrix(0, n+burnin, reptime)
    epsilon <- matrix(rnorm((n+burnin)*reptime,0,1),(n+burnin),reptime)
    cp_sets <- c(0,512,768,1024)
    no_seg <- length(cp_sets)-1
    rho_sets <- list(c(-0.9),c(0.9),c(0))
    sd_sets <- list(c(1,0.7),c(1),c(1,-0.7))
    for(j in 2:(burnin-1)){
      inter[j+1,1:reptime] <- sd_sets[[1]]%*%epsilon[(j+1):(j-length(sd_sets[[1]])+2),1:reptime]+rho_sets[[1]]*inter[j,1:reptime]
    }
    for(index in 1:no_seg){ # Mean shift
      tau1 <- cp_sets[index]+burnin
      tau2 <- cp_sets[index+1]+burnin-1
      for(j in tau1:tau2){
        inter[j+1,1:reptime] <- sd_sets[[index]]%*%epsilon[(j+1):(j-length(sd_sets[[index]])+2),1:reptime]+rho_sets[[index]]*inter[j,1:reptime]
      }
    }
  }
  return(inter[(burnin+1):(n+burnin),1:reptime])
}

#' @useDynLib SNSeg, .registration=TRUE
#' @importFrom mvtnorm rmvnorm
NULL

#' A Funtion to generate a multivariate autoregressive process (MAR) model in
#' time series (used for testing change points based on multivariate mean,
#' covariance and bivariate correlation)
#'
#' The function \code{MAR_MTS_Covariance} is used for generating MAR model(s)
#' for examples under \code{SNSeg_Uni_single_para}, \code{SNSeg_Uni_multi_para},
#' and \code{SNSeg_Multi}.
#'
#' @param n the size of time series to be generated
#' @param reptime the number of time series to be generated
#' @param rho_sets correlation factors for simulation
#' @param cp_sets the critical points set to check SN prediction accuracy
#' @param sigma_cross a list to generate the covariance structure of the time
#' series
#'
#' @export MAR_MTS_Covariance
MAR_MTS_Covariance <- function(n, reptime, rho_sets, cp_sets, sigma_cross){
  no_ts <- dim(sigma_cross[[1]])[1]
  ts_sim <- list()
  burnin <- 100
  no_seg <- length(cp_sets)-1
  for(rep_index in 1:reptime){
    epsilon <- rmvnorm(burnin, mean=rep(0,no_ts), sigma=sigma_cross[[1]])
    inter <- matrix(0, n+burnin, no_ts)
    for (j in 1:(burnin-1)){
      inter[j+1,] <- epsilon[j+1,]+rho_sets[1]*inter[j,]
    }
    for(index in 1:no_seg){ # Mean shift
      tau1 <- cp_sets[index]+burnin
      tau2 <- cp_sets[index+1]+burnin-1
      epsilon <- rmvnorm(tau2-tau1+1, mean=rep(0,no_ts), sigma=sigma_cross[[index]])
      for(j in tau1:tau2){
        inter[j+1,] <- epsilon[(j+1-tau1),]+rho_sets[index]*inter[j,]
      }
    }
    ts_sim[[rep_index]] <- t(inter[(burnin+1):(n+burnin),])
  }
  return(ts_sim)
}


