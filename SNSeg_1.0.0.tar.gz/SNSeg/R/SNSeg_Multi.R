#' @useDynLib SNSeg, .registration=TRUE
#' @importFrom Rcpp evalCpp
NULL

#' @importFrom utils data
#' @importFrom stats approx
#' @importFrom mvtnorm rmvnorm
NULL

#' Self-normalization change points estimation for multivariate time series
#' based on single parameter changes
#'
#' The function \code{SNSeg_Uni} is a single-parameter change point estimation
#' framework for a multivariate time series using the self-normalized approach.
#'
#' @param ts numeric data of a multivariate time series
#' @param type the type of parameters of time series data that SN depends, which
#' includes \code{mean} and \code{covariance}.
#' @param confidence the confidence level that can be expected to produce a
#' significant Self-normalization test statistic
#' @param grid_size_scale the window size parameter to determine the mimimum
#' range where an estimated change point for a time series can occur
#' @param grid_size the window size to cover an estimated change point, which is
#' calculated from grid_size_scale. The function depends on the value of
#' grid_size instead of grid_size_scale within input, and only when grid_size is
#' NULL will the function use the grid_size_scale in the input.
#' @return \code{SNSeg_Multi} returns the type of the multivariate time series,
#' the minimum window size to cover a change point, and the lags of which all
#' estimated change points take place.
#' \describe{
#'   \item{\code{type}}{the type of parameter being used for self-normalization}
#'   \item{\code{grid_size}}{the minimal window size to detect a potential
#'   change point}
#'   \item{\code{SN_sweep_result}}{a list of matrices to record the test
#'   statistics, the location of the estimated change points, and the range of
#'   the window set to contain each change point}
#'   \item{\code{est_cp}}{the estimated change points for the given time series}
#'   \item{\code{confidence}}{the confidence level for SN tests}
#'   \item{\code{critical_value}}{the critical value for SN change points
#'   estimation}
#' }
#'
#' @examples
#' # Please run this function before running examples:
#' exchange_cor_matrix <- function(d, rho){
#'   tmp <- matrix(rho, d, d)
#'   diag(tmp) <- 1
#'   return(tmp)
#' }
#'
#' # SN Segmentation for Multivariate Mean
#' library(mvtnorm)
#' set.seed(10)
#' d <- 5
#' n <- 1000
#' cp_sets <- round(n*c(0,cumsum(c(0.075,0.3,0.05,0.1,0.05)),1))
#' mean_shift <- c(-3,0,3,0,-3,0)/sqrt(d)
#' mean_shift <- sign(mean_shift)*ceiling(abs(mean_shift)*10)/10
#' rho_sets <- 0.5
#' sigma_cross <- list(exchange_cor_matrix(d,0))
#' ts <- MAR_MTS_Covariance(n, 2, rho_sets, cp_sets=c(0,n), sigma_cross)
#' noCP <- length(cp_sets)-2
#' no_seg <- length(cp_sets)-1
#' for(rep_index in 1:2){
#'   for(index in 1:no_seg){ # Mean shift
#'     tau1 <- cp_sets[index]+1
#'     tau2 <- cp_sets[index+1]
#'     ts[[rep_index]][,tau1:tau2] <- ts[[rep_index]][,tau1:tau2] + mean_shift[index]
#'   }
#' }
#' ts <- ts[1][[1]]
#'
#' # grid_size undefined
#' SNSeg_Multi(ts, type = "mean", confidence = 0.95, grid_size_scale = 0.079,
#'             grid_size = NULL)
#' # grid_size defined
#' SNSeg_Multi(ts, type = "mean", confidence = 0.99, grid_size_scale = 0.05,
#'             grid_size = 65)
#'
#' # SN Segmentation for Multivariate Covariance
#' library(mvtnorm)
#' set.seed(10)
#' reptime <- 2
#' d <- 4
#' n <- 1000
#' sigma_cross <- list(exchange_cor_matrix(d,0.2), 2*exchange_cor_matrix(d,0.5),
#'                     4*exchange_cor_matrix(d,0.5))
#' rho_sets <- c(0.3,0.3,0.3)
#' mean_shift <- c(0,0,0) # with mean change
#' cp_sets <- round(c(0,n/3,2*n/3,n))
#' # 2-dimensional AR time series with change-point in bivariate correlation
#' ts <- MAR_MTS_Covariance(n, reptime, rho_sets, cp_sets, sigma_cross)
#' noCP <- length(cp_sets)-2
#' no_seg <- length(cp_sets)-1
#' for(rep_index in 1:reptime){
#'   for(index in 1:no_seg){ # Mean shift
#'     tau1 <- cp_sets[index]+1
#'     tau2 <- cp_sets[index+1]
#'     ts[[rep_index]][,tau1:tau2] <- ts[[rep_index]][,tau1:tau2] + mean_shift[index]
#'   }
#' }
#' ts <- ts[[1]]
#' SNSeg_Multi(ts, type = "covariance", confidence = 0.9, grid_size_scale = 0.05,
#'             grid_size = NULL)
#' SNSeg_Multi(ts, type = "covariance", confidence = 0.9, grid_size_scale = 0.05,
#'             grid_size = 81)
#'
#' @export SNSeg_Multi
SNSeg_Multi <- function(ts, type = "mean", confidence = 0.9, grid_size = NULL,
                        grid_size_scale = 0.05){

  if(is.null(ts))
  {stop("Input of ts is missing!")}
  if(!(type %in% c("mean","covariance"))){
    stop("Type must come be either mean or covariance!")}
  if(!(confidence %in% c(0.9,0.95,0.99,0.995,0.999))){
    stop("Confidence must be one of 0.9, 0.95, 0.99, 0.995 and 0.999!")
  }

  if(class(ts)[1] != "matrix"){
    stop("ts must be a matrix!")
  }
  if(dim(ts)[1] > dim(ts)[2]){ts <- t(ts)}

  n <- dim(ts)[2]
  d <- dim(ts)[1]
  if(type=="covariance"){
    d <- d*(d+1)/2
  }
  if(d > 10){
    stop("The dimension of parameters must be smaller than or equal to 10!")
  }

  critical_values_multi <- SNSeg::critical_values_multi
  # interpolation for grid_size_scale
  if((is.null(grid_size))&(is.null(grid_size_scale))){
    grid_size_scale <- 0.05
    SN_critical <- critical_values_multi[critical_values_multi[,2]==d & critical_values_multi[,1]==grid_size_scale,]
    posi_confidence <- match(as.character(confidence),colnames(critical_values_multi))
    critical_value <- SN_critical[1,posi_confidence]
    grid_size <- round(grid_size_scale*n)
    warning("Undefined value detected for both grid_size and grid_size_scale! The system would use 0.05 as the default for grid_size_scale.")
  } else if((is.null(grid_size))&(!is.null(grid_size_scale))){
    if(grid_size_scale<0.05){
      grid_size_scale <- 0.05
      SN_critical <- critical_values_multi[critical_values_multi[,2]==d & critical_values_multi[,1]==grid_size_scale,]
      posi_confidence <- match(as.character(confidence),colnames(critical_values_multi))
      critical_value <- SN_critical[1,posi_confidence]
      grid_size <- round(grid_size_scale*n)
      warning("Detected the grid_size_scale is less than 0.05. The system would use 0.05 for grid_size_scale.")
    } else if(grid_size_scale>0.5){
      grid_size_scale <- 0.5
      SN_critical <- critical_values_multi[critical_values_multi[,2]==d & critical_values_multi[,1]==grid_size_scale,]
      posi_confidence <- match(as.character(confidence),colnames(critical_values_multi))
      critical_value <- SN_critical[1,posi_confidence]
      grid_size <- round(grid_size_scale*n)
      warning("Detected the grid_size_scale is greater than 0.5. The system would use 0.5 for grid_size_scale.")
    } else if(grid_size_scale>=0.05 & grid_size_scale<=0.5){
      if((grid_size_scale %in% critical_values_multi[,1])){
        SN_critical <- critical_values_multi[critical_values_multi[,2]==d & critical_values_multi[,1]==grid_size_scale,]
        posi_confidence <- match(as.character(confidence),colnames(critical_values_multi))
        critical_value <- SN_critical[1,posi_confidence]
        grid_size <- round(grid_size_scale*n)
      } else if(!(grid_size_scale %in% critical_values_multi[,1])){
        grid_size <- round(grid_size_scale*n)
        SN_critical <- critical_values_multi[critical_values_multi[,2]==d,]
        posi_epsilon <- match(grid_size_scale,sort(c(SN_critical[,1],grid_size_scale)))
        posi_confidence <- match(as.character(confidence),colnames(critical_values_multi))
        critical_vector <- c(SN_critical[(posi_epsilon-1):posi_epsilon,posi_confidence])
        epsilon_vector <- c(SN_critical[(posi_epsilon-1):posi_epsilon,1])
        critical_value <- approx(epsilon_vector,critical_vector,xout = grid_size_scale)$y
      }
    }
  } else if(!is.null(grid_size)){
    grid_size_scale <- grid_size/n
    if(grid_size_scale<0.05){
      grid_size_scale <- 0.05
      grid_size <- round(grid_size_scale*n)
      SN_critical <- critical_values_multi[critical_values_multi[,2]==d & critical_values_multi[,1]==grid_size_scale,]
      posi_confidence <- match(as.character(confidence),colnames(critical_values_multi))
      critical_value <- SN_critical[1,posi_confidence]
      warning("Detected the grid_size_scale is less than 0.05 from the current grid_size. The system would use 0.05 for grid_size_scale.")
    }
    if(grid_size_scale>0.5){
      grid_size_scale <- 0.5
      grid_size <- round(grid_size_scale*n)
      SN_critical <- critical_values_multi[critical_values_multi[,2]==d & critical_values_multi[,1]==grid_size_scale,]
      posi_confidence <- match(as.character(confidence),colnames(critical_values_multi))
      critical_value <- SN_critical[1,posi_confidence]
      warning("Detected the grid_size_scale is greater than 0.5 from the current grid_size. The system would use 0.5 for grid_size_scale.")
    }
    if(grid_size_scale>=0.05 & grid_size_scale<=0.5){
      if((grid_size_scale %in% critical_values_multi[,1])){
        SN_critical <- critical_values_multi[critical_values_multi[,2]==d & critical_values_multi[,1]==grid_size_scale,]
        posi_confidence <- match(as.character(confidence),colnames(critical_values_multi))
        critical_value <- SN_critical[1,posi_confidence]
      } else if(!(grid_size_scale %in% critical_values_multi[,1])){
        SN_critical <- critical_values_multi[critical_values_multi[,2]==d,]
        posi_epsilon <- match(grid_size_scale,sort(c(SN_critical[,1],grid_size_scale)))
        posi_confidence <- match(as.character(confidence),colnames(critical_values_multi))
        critical_vector <- c(SN_critical[(posi_epsilon-1):posi_epsilon,posi_confidence])
        epsilon_vector <- c(SN_critical[(posi_epsilon-1):posi_epsilon,1])
        critical_value <- approx(epsilon_vector,critical_vector,xout = grid_size_scale)$y
      }
    }
  }

  if(type == "mean"){
    SN_sweep_result <- SN_sweep_mean_MTS(ts, grid_size)
    SN_result <- SN_divisive_path(start=1, end=n, grid_size, SN_sweep_result, critical_value=critical_value)
  }

  if(type == "covariance"){
    SN_sweep_result <- SN_sweep_covmatrix_MTS(ts, grid_size)
    SN_result <- SN_divisive_path(start=1, end=n, grid_size, SN_sweep_result, critical_value=critical_value)
  }

  return(list("type" = type, "grid_size" = grid_size, "confidence" = confidence,
              "est_cp" = SN_result, "SN_sweep_result" = SN_sweep_result,
              "critical_value" = critical_value))
}
