#' @useDynLib SNSeg, .registration=TRUE
#' @importFrom Rcpp evalCpp
NULL

#' @importFrom utils data
#' @importFrom stats approx
NULL

#' Self-normalization test statistics segmentation plot for univariate and
#' multivariate time series
#'
#' The function \code{max_SNsweep} is a single-parameter change point estimation
#' framework for a multivariate time series using the self-normalized approach.
#'
#' @param SN_sweep_result a list of matrices containing the SN test statistics
#' from SNSeg_Uni_single_para, SNSeg_Uni_multi_para or SNSeg_Multi
#' @param plot_SN Only if argument plot_SN is TRUE will return a SN test
#' statistic segmentation plot
#'
#' @examples
#' # Please run this function before running examples:
#' exchange_cor_matrix <- function(d, rho){
#'   tmp <- matrix(rho, d, d)
#'   diag(tmp) <- 1
#'   return(tmp)
#' }
#'
#' # univariate time series based on single parameter
#' set.seed(7)
#' n <- 2000
#' reptime <- 2
#' cp_sets <- round(n*c(0,cumsum(c(0.5,0.25)),1))
#' mean_shift <- c(0.4,0,0.4)
#' rho <- -0.7
#' ts <- MAR(n, reptime, rho)
#' no_seg <- length(cp_sets)-1
#' for(index in 1:no_seg){ # Mean shift
#'   tau1 <- cp_sets[index]+1
#'   tau2 <- cp_sets[index+1]
#'   ts[tau1:tau2,] <- ts[tau1:tau2,] + mean_shift[index]
#' }
#' ts <- ts[,2]
#'
#' # calculating SN test statistics and change points
#' result <- SNSeg_Uni_single_para(ts,type = "mean", confidence = 0.9,
#' grid_size_scale = 0.061, grid_size = NULL, plot_SN = FALSE)
#' # SN test statistic segmentation plot
#' max_SNsweep(result$SN_sweep_result, plot_SN = TRUE)
#'
#' # univariate time series based on multi-parameters
#' set.seed(7)
#' n <- 1000
#' cp_sets <- c(0,333,667,1000)
#' no_seg <- length(cp_sets)-1
#' rho <- 0
#' # AR time series with no change-point (mean, var)=(0,1)
#' ts <- MAR(n, 2, rho)*sqrt(1-rho^2)
#' no_seg <- length(cp_sets)-1
#' sd_shift <- c(1,1.6,1)
#' for(index in 1:no_seg){ # Mean shift
#'   tau1 <- cp_sets[index]+1
#'   tau2 <- cp_sets[index+1]
#'   ts[tau1:tau2,] <- ts[tau1:tau2,]*sd_shift[index]
#' }
#' d <- 2
#' ts <- ts[,2]
#'
#' # calculating SN test statistics and change points
#' result <- SNSeg_Uni_multi_para(ts, paras_to_test = c(0.8,'mean',"variance",
#' "acf"), confidence = 0.9, grid_size_scale = 0.05, grid_size = 83, d = 4,
#' plot_SN = FALSE)
#' # SN test statistic segmentation plot
#' max_SNsweep(result$SN_sweep_result, plot_SN = TRUE)
#'
#' # multivariate time series (only support one single parameter!)
#' set.seed(10)
#' d <- 5
#' n <- 1000
#' cp_sets <- round(n*c(0,cumsum(c(0.075,0.3,0.05,0.1,0.05)),1))
#' mean_shift <- c(-3,0,3,0,-3,0)/sqrt(d)
#' mean_shift <- sign(mean_shift)*ceiling(abs(mean_shift)*10)/10
#' rho_sets <- 0.5
#' sigma_cross <- list(exchange_cor_matrix(d,0))
#' ts <- MAR_MTS_Covariance(n, 2, rho_sets, cp_sets=c(0,n), sigma_cross)
#' noCP <- length(cp_sets)-2
#' no_seg <- length(cp_sets)-1
#' for(rep_index in 1:2){
#'   for(index in 1:no_seg){ # Mean shift
#'     tau1 <- cp_sets[index]+1
#'     tau2 <- cp_sets[index+1]
#'     ts[[rep_index]][,tau1:tau2] <- ts[[rep_index]][,tau1:tau2] + mean_shift[index]
#'   }
#' }
#' ts <- ts[1][[1]]
#'
#' # calculating SN test statistics and change points
#' result <- SNSeg_Multi(ts, type = "mean", confidence = 0.9,
#' grid_size_scale = 0.079, grid_size = NULL)
#' # SN test statistic segmentation plot
#' max_SNsweep(result$SN_sweep_result, plot_SN = TRUE)
#'
#' @export max_SNsweep
max_SNsweep <- function(SN_sweep_result, plot_SN = TRUE){
  # max SN test statistic for each lag within the window set
  max_matrix <- function(matrix_data){
    if(is.null(dim(matrix_data))){
      return(0)
    }else{
      return(max(matrix_data[,1]))
    }
  }

  if(is.null(SN_sweep_result)){stop("Input of SN_sweep_result is missing!")}

  SN_test_stat <- sapply(SN_sweep_result, max_matrix)

  if(plot_SN){
    plot(SN_test_stat, xlab = "Time", ylab = "Value",
          main="SN Test Statistic Segmentation Plot")
  }

  return("SN_test_statistic" = SN_test_stat)
}
