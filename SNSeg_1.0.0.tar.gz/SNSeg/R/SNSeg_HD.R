#' @useDynLib SNSeg, .registration=TRUE
#' @importFrom Rcpp evalCpp
NULL

#' Self-normalization change points estimation for high dimensional time series
#' based on changes in multi-means (SNHD).
#'
#' The function \code{SNSeg_HD} is a SNHD change point
#' estimation framework.
#'
#' @param ts numeric data of a univariate time series
#' @param confidence the confidence level that can be expected to produce a
#' significant Self-normalization test statistic. The avaliable confidence
#' levels are 0.9, 0.95, 0.99, 0.995 and 0.999.
#' @param grid_size_scale the window size parameter to determine the mimimum
#' range where an estimated change point for a univariate time series can occur.
#' The grid_size_scale can be selected from the following: 0.05, 0.06, 0.07,
#' 0.08, 0.09, 0.1, 0.11, 0.12, 0.13, 0.14, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4,
#' 0.45 and 0.5.
#' @param grid_size the window size to cover an estimated change point, which is
#' calculated from grid_size_scale. The function depends on the value of
#' grid_size instead of grid_size_scale within input, and only when grid_size is
#' NULL will the function use the grid_size_scale in the input.
#' @return SNSeg_HD returns the minimum window size to cover a change point,
#' and the lags of which all estimated change points take place.
#' \describe{
#'   \item{\code{grid_size}}{the minimal window size to detect a potential
#'   change point}
#'   \item{\code{SN_sweep_result}}{a list of matrices to record the test
#'   statistics, the location of the estimated change points, and the range of
#'   the window set to contain each change point}
#'   \item{\code{est_cp}}{the estimated change points for the given time series}
#'   \item{\code{confidence}}{the confidence level for SN tests}
#'   \item{\code{critical_value}}{the critical value for SN change points
#'   estimation}
#' }
#'
#' @examples
#' n <- 600
#' p <- 100
#' nocp <- 5
#' cp_sets <- round(seq(0,nocp+1,1)/(nocp+1)*n)
#' num_entry <- 5
#' kappa <- sqrt(4/5) # Wang et al(2020)
#' mean_shift <- rep(c(0,kappa),100)[1:(length(cp_sets)-1)]
#' set.seed(1)
#' ts <- matrix(rnorm(n*p,0,1),n,p)
#' no_seg <- length(cp_sets)-1
#' for(index in 1:no_seg){ # Mean shift
#'   tau1 <- cp_sets[index]+1
#'   tau2 <- cp_sets[index+1]
#'   ts[tau1:tau2,1:num_entry] <- ts[tau1:tau2,1:num_entry] + mean_shift[index] # sparse change
#' }
#' # grid_size undefined
#' SNSeg_HD(ts, confidence = 0.9, grid_size_scale = 0.05,
#'          grid_size = NULL)
#' # grid_size defined
#' SNSeg_HD(ts, confidence = 0.9, grid_size_scale  = 0.05,
#'          grid_size = 52)
#' @export SNSeg_HD
SNSeg_HD <- function(ts, confidence = 0.9, grid_size_scale = 0.05,
                     grid_size = NULL){
  if(is.null(ts))
  {stop("Input of ts is missing!")}
  if(dim(ts)[1]<dim(ts)[2]){
    ts <- t(ts)
  }

  if(!(confidence %in% c(0.9,0.95,0.99,0.995,0.999))){
    stop("Confidence must be one of 0.9, 0.95, 0.99, 0.995 and 0.999!")
  }
  n <- dim(ts)[1]
  critical_values_HD <- SNSeg::critical_values_HD
  # interpolation for grid_size_scale
  if((is.null(grid_size))&(is.null(grid_size_scale))){
    grid_size_scale <- 0.05
    posi_confidence <- match(as.character(confidence),colnames(critical_values_HD))
    critical_value <- critical_values_HD[1,posi_confidence]
    grid_size <- floor(grid_size_scale*n)
    warning("Undefined value detected for both grid_size and grid_size_scale! The system would use 0.05 as the default for grid_size_scale.")
  } else if((is.null(grid_size))&(!is.null(grid_size_scale))){
    if(grid_size_scale<0.05){
      grid_size_scale <- 0.05
      posi_confidence <- match(as.character(confidence),colnames(critical_values_HD))
      critical_value <- critical_values_HD[1,posi_confidence]
      grid_size <- floor(grid_size_scale*n)
      warning("Detected the grid_size_scale is less than 0.05. The system would use 0.05 for grid_size_scale.")
    }
    if(grid_size_scale>0.5){
      grid_size_scale <- 0.5
      posi_confidence <- match(as.character(confidence),colnames(critical_values_HD))
      critical_value <- critical_values_HD[10,posi_confidence]
      grid_size <- floor(grid_size_scale*n)
      warning("Detected the grid_size_scale is greater than 0.5. The system would use 0.5 for grid_size_scale.")
    }
    if(grid_size_scale>=0.05 & grid_size_scale<=0.5){
      if((grid_size_scale %in% critical_values_HD[,1])){
        posi_cri <- match(as.character(grid_size_scale),critical_values_HD[,1])
        posi_confidence <- match(as.character(confidence),colnames(critical_values_HD))
        critical_value <- critical_values_HD[posi_cri,posi_confidence]
        grid_size <- floor(grid_size_scale*n)
      } else if(!(grid_size_scale %in% critical_values_HD[,1])){
        grid_size <- floor(grid_size_scale*n)
        posi_epsilon <- match(grid_size_scale,sort(c(critical_values_HD[,1],grid_size_scale)))
        posi_confidence <- match(as.character(confidence),colnames(critical_values_HD))
        critical_vector <- c(critical_values_HD[(posi_epsilon-1):posi_epsilon,posi_confidence])
        epsilon_vector <- c(critical_values_HD[(posi_epsilon-1):posi_epsilon,1])
        critical_value <- approx(epsilon_vector,critical_vector,xout = grid_size_scale)$y
      }
    }
  } else if(!is.null(grid_size)){
    grid_size_scale <- grid_size/n
    if(grid_size_scale<0.05){
      grid_size_scale <- 0.05
      grid_size <- round(grid_size_scale*n)
      posi_confidence <- match(as.character(confidence),colnames(critical_values_HD))
      critical_value <- critical_values_HD[1,posi_confidence]
      warning("Detected the grid_size_scale is less than 0.05 from the current grid_size. The system would use 0.05 for grid_size_scale.")
    }
    if(grid_size_scale>0.5){
      grid_size_scale <- 0.5
      grid_size <- round(grid_size_scale*n)
      posi_confidence <- match(as.character(confidence),colnames(critical_values_HD))
      critical_value <- critical_values_HD[10,posi_confidence]
      warning("Detected the grid_size_scale is greater than 0.5 from the current grid_size. The system would use 0.5 for grid_size_scale.")
    }
    if(grid_size_scale>=0.05 & grid_size_scale<=0.5){
      if((grid_size_scale %in% critical_values_HD[,1])){
        posi_cri <- match(as.character(grid_size_scale),critical_values_HD[,1])
        posi_confidence <- match(as.character(confidence),colnames(critical_values_HD))
        critical_value <- critical_values_HD[posi_cri,posi_confidence]
      } else if(!(grid_size_scale %in% critical_values_HD[,1])){
        posi_epsilon <- match(grid_size_scale,sort(c(critical_values_HD[,1],grid_size_scale)))
        posi_confidence <- match(as.character(confidence),colnames(critical_values_HD))
        critical_vector <- c(critical_values_HD[(posi_epsilon-1):posi_epsilon,posi_confidence])
        epsilon_vector <- c(critical_values_HD[(posi_epsilon-1):posi_epsilon,1])
        critical_value <- approx(epsilon_vector,critical_vector,xout = grid_size_scale)$y
      }
    }
  }

  SN_sweep_result <- SN_sweep_mean_HD(ts, grid_size)
  SN_result <- SN_divisive_path(start=1, end=n, grid_size, SN_sweep_result, critical_value=critical_value)

  return(list("grid_size" = grid_size,"est_cp" = SN_result,"confidence" = confidence,
              "SN_sweep_result" = SN_sweep_result,"critical_value" = critical_value))
}
