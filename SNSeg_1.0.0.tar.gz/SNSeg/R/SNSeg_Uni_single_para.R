#' @useDynLib SNSeg, .registration=TRUE
#' @importFrom Rcpp evalCpp
NULL

#' @importFrom utils data
#' @importFrom stats approx
#' @importFrom graphics plot
#' @importFrom graphics abline
#' @importFrom mvtnorm rmvnorm
NULL

#' Self-normalization change points estimation for univariate time series based
#' on one single parameter changes
#'
#' The function \code{SNSeg_Uni_single_para} is a single-parameter change point
#' estimation framework for a univariate time series using the self-normalized
#' approach.
#'
#' @param ts numeric data of a univariate time series
#' @param type the type of parameters of time series data that SN depends, which
#' includes \code{mean}, \code{variance}, \code{acf}, \code{bivcor} and
#' \code{quantile}.
#' @param confidence the confidence level that can be expected to produce a
#' significant Self-normalization test statistic. The avaliable confidence
#' levels are 0.9, 0.95, 0.99, 0.995 and 0.999.
#' @param quantile_level the quantile level of the given time series
#' @param grid_size_scale the window size parameter to determine the mimimum
#' range where an estimated change point for a univariate time series can occur.
#' The grid_size_scale can be selected from the following: 0.05, 0.06, 0.07,
#' 0.08, 0.09, 0.1, 0.11, 0.12, 0.13, 0.14, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4,
#' 0.45 and 0.5.
#' @param grid_size the window size to cover an estimated change point, which is
#' calculated from grid_size_scale. The function depends on the value of
#' grid_size instead of grid_size_scale within input, and only when grid_size is
#' NULL will the function use the grid_size_scale in the input.
#' @param plot_SN Only if argument plot_SN is TRUE will return an SN
#' segmentation plot
#' @return SNSeg_Uni_single_para returns the type of the univariate time series,
#' the minimum window size to cover a change point, and the lags of which all
#' estimated change points take place.
#' \describe{
#'   \item{\code{type}}{the type of parameter being used for self-normalization}
#'   \item{\code{grid_size}}{the minimal window size to detect a potential
#'   change point}
#'   \item{\code{SN_sweep_result}}{a list of matrices to record the test
#'   statistics, the location of the estimated change points, and the range of
#'   the window set to contain each change point}
#'   \item{\code{est_cp}}{the estimated change points for the given time series}
#'   \item{\code{confidence}}{the confidence level for SN tests}
#'   \item{\code{critical_value}}{the critical value for SN change points
#'   estimation}
#' }
#'
#' @examples
#' # Please run the following function before running examples:
#' mix_GauGPD <- function(u,p,trunc_r,gpd_scale,gpd_shape){
#'   indicator <- u<p
#'   rv <- rep(0, length(u))
#'   rv[indicator>0] <- qtruncnorm(u[indicator>0]/p,a=-Inf,b=trunc_r)
#'   rv[indicator<=0] <- qgpd((u[indicator<=0]-p)/(1-p),loc=trunc_r,scale=gpd_scale,shape=gpd_shape)
#'   return(rv)
#' }
#'
#' # SN Segmentation for Mean
#' set.seed(7)
#' n <- 2000
#' reptime <- 2
#' cp_sets <- round(n*c(0,cumsum(c(0.5,0.25)),1))
#' mean_shift <- c(0.4,0,0.4)
#' rho <- -0.7
#' ts <- MAR(n, reptime, rho)
#' no_seg <- length(cp_sets)-1
#' for(index in 1:no_seg){ # Mean shift
#'   tau1 <- cp_sets[index]+1
#'   tau2 <- cp_sets[index+1]
#'   ts[tau1:tau2,] <- ts[tau1:tau2,] + mean_shift[index]
#' }
#' ts <- ts[,2]
#' # grid_size undefined
#' SNSeg_Uni_single_para(ts,type = "mean", confidence = 0.9,
#'        grid_size_scale = 0.05, grid_size = NULL, plot_SN = FALSE)
#' # grid_size defined
#' SNSeg_Uni_single_para(ts,type = "mean", confidence = 0.9,
#'        grid_size_scale = 0.05, grid_size = 116, plot_SN = FALSE)
#'
#' # SN Segmentation for Variance
#' set.seed(7)
#' ts <- MAR_Variance(2, "V1")
#' ts <- ts[,2]
#' # grid_size undefined
#' SNSeg_Uni_single_para(ts,type = "variance", confidence = 0.9,
#'        grid_size_scale = 0.067, grid_size = NULL, plot_SN = FALSE)
#' # grid_size defined
#' SNSeg_Uni_single_para(ts,type = "variance", confidence = 0.9,
#'        grid_size_scale = 0.05, grid_size = 67, plot_SN = FALSE)
#'
#' # SN Segmentation for ACF
#' set.seed(7)
#' ts <- MAR_Variance(2, "A3")
#' ts <- ts[,2]
#' # grid_size undefined
#' SNSeg_Uni_single_para(ts,type = "acf", confidence = 0.9,
#'        grid_size_scale = 0.05, grid_size = NULL, plot_SN = FALSE)
#' # grid_size defined
#' SNSeg_Uni_single_para(ts,type = "acf", confidence = 0.9,
#'        grid_size_scale = 0.05, grid_size = 92, plot_SN = FALSE)
#'
#' # SN Segmentation for bivariate correlation
#' library(mvtnorm)
#' set.seed(7)
#' n <- 1000
#' sigma_cross <- list(4*matrix(c(1,0.8,0.8,1), nrow=2),
#'       matrix(c(1,0.2,0.2,1), nrow=2), matrix(c(1,0.8,0.8,1), nrow=2))
#' cp_sets <- round(c(0,n/3,2*n/3,n))
#' noCP <- length(cp_sets)-2
#' rho_sets <- rep(0.5, noCP+1)
#' ts <- MAR_MTS_Covariance(n, 2, rho_sets, cp_sets, sigma_cross)
#' ts <- ts[1][[1]]
#' # grid_size undefined
#' SNSeg_Uni_single_para(ts,type = "bivcor", confidence = 0.9,
#'         grid_size_scale = 0.05, grid_size = NULL, plot_SN = TRUE)
#' # grid_size defined
#' SNSeg_Uni_single_para(ts,type = "bivcor", confidence = 0.9,
#'         grid_size_scale = 0.05, grid_size = 77, plot_SN = TRUE)
#'
#' # SN Segmentation for quantile
#' library(truncnorm)
#' library(evd)
#' set.seed(7)
#' n <- 1000
#' cp_sets <- c(0,n/2,n)
#' noCP <- length(cp_sets)-2
#' reptime <- 2
#' rho <- 0.2
#' # AR time series with no change-point (mean, var)=(0,1)
#' ts <- MAR(n, reptime, rho)*sqrt(1-rho^2)
#' trunc_r <- 0
#' p <- pnorm(trunc_r)
#' gpd_scale <- 2
#' gpd_shape <- 0.125
#' for(ts_index in 1:reptime){
#'   ts[(cp_sets[2]+1):n, ts_index] <- mix_GauGPD(pnorm(ts[(cp_sets[2]+1):n, ts_index]),
#'                                      p,trunc_r,gpd_scale,gpd_shape)
#' }
#' ts <- ts[,2]
#' SNSeg_Uni_single_para(ts,type = "quantile", confidence = 0.9, quantile_level = 0.9,
#'         grid_size_scale = 0.066, grid_size = NULL, plot_SN = TRUE)
#' SNSeg_Uni_single_para(ts,type = "quantile", confidence = 0.9, quantile_level = 0.8,
#'         grid_size_scale = 0.05, grid_size = 102, plot_SN = TRUE)
#'
#' @export SNSeg_Uni_single_para
SNSeg_Uni_single_para <- function(ts, type = "mean", confidence = 0.9,
                      quantile_level = 0.1, grid_size_scale = 0.05, grid_size = NULL,
                      plot_SN = FALSE){
  if(is.null(ts))
    {stop("Input of ts is missing!")}
  if(!(type %in% c("mean","variance","acf","bivcor","quantile"))){
    stop("Type must come from one of the categories: mean, variance, acf,
         bivcor, quantile!")}
  if(!(confidence %in% c(0.9,0.95,0.99,0.995,0.999))){
    stop("Confidence must be one of 0.9, 0.95, 0.99, 0.995 and 0.999!")
  }

  if(type %in% c("mean","variance","acf","quantile")){
    if(class(ts)[1] != "numeric"){
      stop("ts must be numeric!")
    }
    n <- length(ts)
  }
  if(type == "bivcor"){
    if(class(ts)[1] != "matrix"){
      stop("ts must be a matrix!")
    }
    if(!((dim(ts)[1] == 2) | (dim(ts)[2] == 2))){
      stop("ts must be 2-dimensional!")
    }

    if(dim(ts)[2] == 2) {ts <- t(ts)}
    n <- dim(ts)[2]
  }

  critical_values_single <- SNSeg::critical_values_single
  # interpolation for grid_size_scale
  if((is.null(grid_size))&(is.null(grid_size_scale))){
    grid_size_scale <- 0.05
    posi_confidence <- match(as.character(confidence),colnames(critical_values_single))
    critical_value <- critical_values_single[1,posi_confidence]
    grid_size <- floor(grid_size_scale*n)
    warning("Undefined value detected for both grid_size and grid_size_scale! The system would use 0.05 as the default for grid_size_scale.")
  } else if((is.null(grid_size))&(!is.null(grid_size_scale))){
    if(grid_size_scale<0.05){
      grid_size_scale <- 0.05
      posi_confidence <- match(as.character(confidence),colnames(critical_values_single))
      critical_value <- critical_values_single[1,posi_confidence]
      grid_size <- floor(grid_size_scale*n)
      warning("Detected the grid_size_scale is less than 0.05. The system would use 0.05 for grid_size_scale.")
    }
    if(grid_size_scale>0.5){
      grid_size_scale <- 0.5
      posi_confidence <- match(as.character(confidence),colnames(critical_values_single))
      critical_value <- critical_values_single[18,posi_confidence]
      grid_size <- floor(grid_size_scale*n)
      warning("Detected the grid_size_scale is greater than 0.5. The system would use 0.5 for grid_size_scale.")
    }
    if(grid_size_scale>=0.05 & grid_size_scale<=0.5){
      if((grid_size_scale %in% critical_values_single[,1])){
        posi_cri <- match(as.character(grid_size_scale),critical_values_single[,1])
        posi_confidence <- match(as.character(confidence),colnames(critical_values_single))
        critical_value <- critical_values_single[posi_cri,posi_confidence]
        grid_size <- floor(grid_size_scale*n)
      } else if(!(grid_size_scale %in% critical_values_single[,1])){
        grid_size <- floor(grid_size_scale*n)
        posi_epsilon <- match(grid_size_scale,sort(c(critical_values_single[,1],grid_size_scale)))
        posi_confidence <- match(as.character(confidence),colnames(critical_values_single))
        critical_vector <- c(critical_values_single[(posi_epsilon-1):posi_epsilon,posi_confidence])
        epsilon_vector <- c(critical_values_single[(posi_epsilon-1):posi_epsilon,1])
        critical_value <- approx(epsilon_vector,critical_vector,xout = grid_size_scale)$y
      }
    }
  } else if(!is.null(grid_size)){
    grid_size_scale <- grid_size/n
    if(grid_size_scale<0.05){
      grid_size_scale <- 0.05
      grid_size <- round(grid_size_scale*n)
      posi_confidence <- match(as.character(confidence),colnames(critical_values_single))
      critical_value <- critical_values_single[1,posi_confidence]
      warning("Detected the grid_size_scale is less than 0.05 from the current grid_size. The system would use 0.05 for grid_size_scale.")
    }
    if(grid_size_scale>0.5){
      grid_size_scale <- 0.5
      grid_size <- round(grid_size_scale*n)
      posi_confidence <- match(as.character(confidence),colnames(critical_values_single))
      critical_value <- critical_values_single[18,posi_confidence]
      warning("Detected the grid_size_scale is greater than 0.5 from the current grid_size. The system would use 0.5 for grid_size_scale.")
    }
    if(grid_size_scale>=0.05 & grid_size_scale<=0.5){
      if((grid_size_scale %in% critical_values_single[,1])){
        posi_cri <- match(as.character(grid_size_scale),critical_values_single[,1])
        posi_confidence <- match(as.character(confidence),colnames(critical_values_single))
        critical_value <- critical_values_single[posi_cri,posi_confidence]
      } else if(!(grid_size_scale %in% critical_values_single[,1])){
        posi_epsilon <- match(grid_size_scale,sort(c(critical_values_single[,1],grid_size_scale)))
        posi_confidence <- match(as.character(confidence),colnames(critical_values_single))
        critical_vector <- c(critical_values_single[(posi_epsilon-1):posi_epsilon,posi_confidence])
        epsilon_vector <- c(critical_values_single[(posi_epsilon-1):posi_epsilon,1])
        critical_value <- approx(epsilon_vector,critical_vector,xout = grid_size_scale)$y
      }
    }
  }

  # Mean
  if(type == "mean"){

    # SN change points estimate
    SN_sweep_result <- SN_sweep_mean(ts, grid_size)
    SN_result <- SN_divisive_path(start=1, end=n, grid_size, SN_sweep_result, critical_value=critical_value)

    if(plot_SN){
      plot(ts, xlab = "Time", ylab = "Value",
           main="SN Segmentation plot for Univariate Mean")
      abline(v=SN_result)
    }
  }

  # Variance
  else if (type == "variance"){

    # SN change points estimate
    SN_sweep_result <- SN_sweep_variance(ts, grid_size)
    SN_result <- SN_divisive_path(start=1, end=n, grid_size, SN_sweep_result, critical_value=critical_value)

    if(plot_SN){
      plot(ts, xlab = "Time", ylab = "Value",
           main="SN Segmentation plot for Univariate Variance")
      abline(v=SN_result)
    }
  }

  # ACF
  else if(type == "acf"){

    # SN change points estimate
    SN_sweep_result <- SN_sweep_acf(ts, grid_size)
    SN_result <- SN_divisive_path(start=1, end=n, grid_size, SN_sweep_result, critical_value=critical_value)

    if(plot_SN){
      plot(ts, xlab = "Time", ylab = "Value",
           main="SN Segmentation plot for Univariate ACF")
      abline(v=SN_result)
    }
  }

  # bivariate correlation
  else if(type == "bivcor"){

    # SN change points estimate
    SN_sweep_result <- SN_sweep_bivcor(ts, grid_size)
    SN_result <- SN_divisive_path(start=1, end=n, grid_size, SN_sweep_result, critical_value=critical_value)

    if(plot_SN){
      par(mfrow=c(1,2))
      plot(ts[1,], xlab = "Time", ylab = "Value",
           main="SN Segmentation plot for Bivariate Correlation")
      abline(v=SN_result)
      plot(ts[2,], xlab = "Time", ylab = "Value",
           main="SN Segmentation plot for Bivariate Correlation")
      abline(v=SN_result)
    }
  }

  # Quantile
  else if(type == "quantile"){

    # SN change points estimate
    SN_sweep_result <- SN_sweep_quantile(ts, grid_size, quantile_level)
    SN_result <- SN_divisive_path(start=1, end=n, grid_size, SN_sweep_result, critical_value=critical_value)

    if(plot_SN){
      plot(ts, xlab = "Time", ylab = "Value",
           main=paste0("SN Segmentation plot for ",quantile_level*100,"th Quantile"))
      abline(v=SN_result)
    }
  }
  return(list("type" = type, "grid_size" = grid_size, "confidence" = confidence,
               "est_cp" = SN_result, "SN_sweep_result" = SN_sweep_result,
              "critical_value" = critical_value))
}

