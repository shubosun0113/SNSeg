#' SNSeg: A package for Self-normalization (SN) on change points estimation in
#' time series.
#'
#' The SNuni package provides three important functions:
#' \code{SNSeg_Uni_single_para}, \code{SNSeg_Uni_multi_para} and \code{SNSeg_Multi}.
#' Since SN-based testing approach uses test statistic to make change point
#' estimates, two critical value tables (\code{critical_values_single} and
#' \code{critical_values_multi}) were attached.
#'
#' @section SNSeg_Uni_single_para:
#' \code{SNSeg_Uni_single_para} provides change points estimates for a
#' univariate time series based on changes in a single parameter using
#' self-normalized approach.
#'
#' For the parameters of the user-defined time series, the function
#' \code{SNSeg_Uni_single_para} offers mean, variance, acf, bivariate
#' correlation and quantiles as avaliale choice. To visualize the changes in
#' time series, users can set "plot_SN = TRUE" to see the SN segmentation plot.
#' The output includes the type of the parameter, the minimal window size to
#' contain a potential change point, and the lag(s) where the change point(s)
#' occur.
#'
#' @section SNSeg_Uni_multi_para:
#' \code{SNSeg_Uni_mul_para} provides change points estimates for a
#' univariate time series based on changes in multi-parameters using
#' self-normalized approach.
#'
#' Different from \code{SNSeg_Uni_single_para}, \code{SNSeg_Uni_multi_para}
#' allows users to place multiple parameters as input. Users can also get the
#' segmentation plot by setting "plot_SN = TRUE". The output is the same as
#' those of \code{SNSeg_Uni_single_para}.
#'
#' @section SNSeg_Multi:
#' \code{SNSeg_Multi} provides change points estimates for a multivariate time
#' series based on changes in single-parameter using self-normalized approach.
#'
#' Different from \code{SNSeg_Uni_single_para} and \code{SNSeg_Uni_mul_para},
#' \code{SNSeg_Multi} does not provide the segmentation plots for users. Users
#' can plot each of the time series by "plot()" and add "abline(v = ...)", of
#' which "..." represents the change point location from \code{SNSeg_Multi}'s
#' output. The other output of \code{SNSeg_Multi} is the same as the previous
#' two functions.
#'
#' @section critical values table:
#' The package \code{SNuni} provides two critical values table.
#'
#' Table \code{critical_values_single} records critical values of each window
#' size at each confidence level for SN change points estimate based on
#' one single parameter.
#'
#' Table \code{critical_values_multi} records critical values of each window
#' size at each confidence level for SN change points estimate based on
#' multi-parameters.
#'
#' @docType package
#' @name SNSeg
NULL
#> NULL
